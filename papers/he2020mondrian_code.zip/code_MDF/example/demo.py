import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from src.gcForest import gcForest
import numpy as np
import time

def generate_dataset(n_samples, effective_dimension, dimension):
    dim = dimension
    J_dim = effective_dimension
    X = np.random.randint(0,2,(n_samples, dim))
    X_J = X[:,:J_dim]
    Sum_X_J = np.sum(X_J, axis = 1)
    Ind=np.zeros(n_samples)
    Ind[Sum_X_J>1]=1
    Y=Ind
    Y = np.int8(Y)
    return X, Y

def compute_accuracy(label, predict):
    if len(predict.shape) > 1:
        test = np.argmax(predict, axis=1)
    else:
        test = predict
    test_copy = test.astype("int")
    label_copy = label.astype("int")
    acc = np.sum(test_copy == label_copy) * 1.0 / len(label_copy) * 100
    return acc

if __name__ == '__main__':
    print("**********", time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()), "**********")

    n_samples = 200
    effective_dimension = 2
    irrelevant_dimension = 8
    X_train, y_train = generate_dataset(n_samples, effective_dimension, effective_dimension + irrelevant_dimension)
    X_test, y_test = generate_dataset(500, effective_dimension, effective_dimension + irrelevant_dimension)
    n_dim = X_train.shape[1]

    n_estimators = 20  # number of trees in each forest
    num_forests = 6
    print("n_estimators = {}, num_forests = {}".format(n_estimators, num_forests))

    scale = 2 * num_forests / n_dim

    X_train = X_train * scale
    X_test = X_test * scale
    X_train = np.float16(X_train)
    X_test = np.float16(X_test)
    X_train = np.float64(X_train)
    X_test = np.float64(X_test)

    gc = gcForest(n_estimators, num_forests, 100, 100, 3)

    val_p, val_acc, test_p, test_acc, best_layer_index = \
        gc.train_and_predict(X_train, y_train, X_test, y_test)

    print('best = %d' % best_layer_index)
    print('val_acc = %s' % val_acc)
    print('test_acc = %s' % test_acc)
    print('accuracy: {}, {} layers'.format(test_acc[best_layer_index], best_layer_index+1))
