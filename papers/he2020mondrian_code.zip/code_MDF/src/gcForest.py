from sklearn.model_selection import KFold

# from sklearn.cross_validation import KFold
# from .layer import *
from .layer import *

class gcForest:
    def __init__(self, num_estimator, num_forests, max_layer=100, max_depth=31, n_fold=5):
        self.num_estimator = num_estimator
        self.num_forests = num_forests
        self.n_fold = n_fold
        self.max_depth = max_depth
        self.max_layer = max_layer
        self.num_classes = 2 # default, modify later

    def train_and_predict(self, train_data, train_label, test_data, test_label):
        # basis information of dataset
        self.num_classes = int(np.max(train_label) + 1)
        num_samples, num_features = train_data.shape

        # basis process

        train_data_raw = train_data.copy()
        test_data_raw = test_data.copy()

        # return value
        train_p = []
        train_acc = []
        val_p = []
        val_acc = []
        test_p = []
        test_acc = []

        best_train_acc = 0.0
        layer_index = 0
        best_layer_index = 0
        bad = 0

        # weight = np.ones(num_samples) / num_samples

        # temp = KFold(n_splits=self.n_fold, shuffle=True)
        # kf = []
        # for i, j in temp.split(range(len(train_label))):
        #     kf.append([i, j])

        # kf = KFold(len(train_label), n_folds=self.n_fold, shuffle=True)

        while layer_index < self.max_layer:

            layer = Layer(self.num_forests, self.num_estimator, self.num_classes,
                          self.n_fold, layer_index, self.max_depth, 1)

            val_prob, val_stack, test_prob, test_stack = \
                layer.train_and_predict(train_data, train_label, test_data)

            train_data = np.concatenate([train_data_raw, val_stack], axis=1)
            test_data = np.concatenate([test_data_raw, test_stack], axis=1)
            # train_data = np.hstack((train_data_raw, val_stack))
            # test_data = np.hstack((test_data_raw, test_stack))
            train_data = np.float16(train_data)
            test_data = np.float16(test_data)
            train_data = np.float64(train_data)
            test_data = np.float64(test_data)

            temp_val_acc = compute_accuracy(train_label, val_prob)
            temp_test_acc = compute_accuracy(test_label, test_prob)

            if False:
                print("layer " + str(layer_index))
                print("val   acc:" + str(temp_val_acc))
                print("test  acc:" + str(temp_test_acc))

            # val_p.append(val_prob)
            # test_p.append(test_prob)
            test_acc.append(temp_test_acc)
            val_acc.append(temp_val_acc)

            if best_train_acc >= temp_val_acc:
                bad += 1
            else:
                bad = 0
                best_train_acc = temp_val_acc
                best_layer_index = layer_index
            if bad >= 3:
                break

            layer_index = layer_index + 1

        return [val_p, val_acc, test_p, test_acc, best_layer_index]
